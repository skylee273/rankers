package com.project.rankers.model

class Depart (val depart : String)