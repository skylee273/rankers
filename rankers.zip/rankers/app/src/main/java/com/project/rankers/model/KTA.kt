package com.project.rankers.model

class KTA (val type : String, val date : String, val title : String, val address : String)