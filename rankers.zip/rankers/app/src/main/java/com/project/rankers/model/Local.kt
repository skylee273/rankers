package com.project.rankers.model

class Local(val type : String, val date : String, val title : String, val address : String)