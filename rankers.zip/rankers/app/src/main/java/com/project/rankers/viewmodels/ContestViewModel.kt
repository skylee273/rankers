package com.project.rankers.viewmodels

import android.databinding.BaseObservable

class ContestViewModel : BaseObservable()